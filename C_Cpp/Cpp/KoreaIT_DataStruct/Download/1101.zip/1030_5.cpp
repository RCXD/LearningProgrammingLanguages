// "�������" -> [����]�̿�!
#include<stdio.h>
#include<stdlib.h>
void push(int *stack,int index,int data) {
	stack[index] = data;
}
int main() {

	int len;
	printf("���� 1�� �Է�: ");
	scanf("%d", &len);
	int* stack = (int*)malloc(len * sizeof(int));
	int index = -1;
	for (int i = 0; i < len; i++) {
		int data;
		scanf("%d", &data);
		if (data) {
			index++;
			push(stack, index, data);
		}
		else {
			index--;
		}
	}

	int sum = 0;
	for (int i = 0; i <= index; i++) {
		printf("%d ", stack[i]);
		sum += stack[i];
	}
	printf("����/��� == %d / %.2lf\n", sum, sum *1.0/ (index+1) );

	return 0;
}