// 7 3
// 3 6 2 7 5 1 4
#include<stdio.h>
#include<stdlib.h>
typedef struct NODE {
	int data;
	struct NODE* next;
}N;
void add(N* root, int data) {
	N* node = (N*)malloc(sizeof(N));
	node->data = data;
	node->next = NULL;
	N* p=root;
	while (p->next != NULL) {
		p = p->next;
	}
	p->next = node;
}
void add2(N* root, int data) {
	N* node = (N*)malloc(sizeof(N));
	node->data = data;
	node->next = NULL;
	N* p = root;
	while (p->next != NULL) {
		p = p->next;
	}
	p->next = node;
	node->next = root->next; // ����Ŭ�� ����!
}
int main() {

	int a, b;
	scanf("%d%d", &a, &b);
	// h->1->2->3-> ... -> 7
	
	N* head = (N*)malloc(sizeof(N));
	head->next = NULL;
	for (int i = 0; i < a-1; i++) {
		add(head, i + 1);
	}
	add2(head, a);

	N* p = head;
	int cnt = 0;
	int c = 0;
	while (c!=a) {
		cnt++;
		if (cnt == b) {
			c++;
			cnt = 0;
			printf("%d ", p->next->data);
			p->next = p->next->next;
			continue;
		}
		p = p->next;
	}
	printf("\n\n");
	/*
	N* p = head->next;
	while (p!=NULL) {
		printf("%d ", p->data);
		p = p->next;
	}
	*/

	return 0;
}