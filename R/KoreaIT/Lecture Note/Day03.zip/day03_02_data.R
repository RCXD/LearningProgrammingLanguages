# day03_02_data
# 데이터 전처리

df_web <- read.csv('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/my_lib.csv')
df_web

# 결측치 확인
is.na(df_web)
table(is.na(df_web))


# 각 컬럼에 대한 정보 확인
str(df_web)

# 상위 6개만 눈으로 보기
head(df_web)


install.packages('dplyr')
library('dplyr')

# filter(): 행 추출
# select(): 열 추출
# arrange(): 정렬
# mutate(): 열 추가
# group_by(): 집단(그룹) 묶기

# 데이터 분석 목표: 전국 도서관의 시도명, 시군구명, 도서관 유형을
# 그룹화하기
df_web
df_web[, c('시도명', '시군구명')]

# 시도명으로 그룹화하기
df_lib_g <- subset(df_web, select = c('시도명', '시군구명', '도서관유형'))
head(df_lib_g)

cnt <- group_by(df_lib_g, 시도명)
count(cnt)

# 시도명, 시군구명으로 그룹화하기
cnt <- group_by(df_lib_g, 시도명, 시군구명)
count(cnt)


# 칼럼명 변경하기
colnames(df_lib_g) <- c('sido', 'sigungu', 'type')
head(df_lib_g)
group_by(df_lib_g, sido)
count(group_by(df_lib_g, sido))


count(group_by(df_lib_g, sido, sigungu))


# 숙제하기. dplyr을 이용하지 않고, 시도명이 서울특별시인
# 데이터의 갯수를 구해주세요.












# 정렬하기

cnt <- count(group_by(df_lib_g, sido, sigungu))
cnt
c(order(cnt$n))   # 오름차순
c(order(-cnt$n))   # 내림차순

cnt[c(order(cnt$n)), ]
lib_cnt <- cnt[c(order(-cnt$n)), ]



# 데이터 저장하기(데이터, 경로)
write.table(lib_cnt, 'c:/dev/lib.cnt.txt')
write.csv(lib_cnt, 'lib_cnt.csv', row.names = F)





























































