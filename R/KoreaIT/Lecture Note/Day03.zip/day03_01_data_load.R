# day03_01_data_load 
## 지난 시간 복습 및 기본 함수

fruit <- c('apple', 'mango', 'banana', 'orange', 'Apple', 'pineapple')
fruit

### 특정 조건 검색
# - fruit 안에서 apple이라는 값 검색하기
# grep(조건, 데이터)
grep('apple', fruit) # 5번은 a가 대문자여서 조건이 안 맞음

# - 대소문자를 구분 없애기
grep('apple', fruit, ignore.case = T)


# fruit 안에서 a가 포함된 값 검색하기
grep('a', fruit)


# 시작과 끝값으로 검색하기
grep('^a', fruit)  # a로 시작하는 값만 검색해라.
grep('e$', fruit)  # e로 끝나는 값만 검색해라.


# fruit 에 논리값과 숫자값을 1개씩 추가
fruit <- c(fruit, TRUE, 123)


# 숫자형태만 검색하기
grep('\\d', fruit) 

# 숫자형태가 아닌 값만 검색하기
grep('\\D', fruit)

# 임의의 텍스트 수 지정하여 검색하기
# - . 하나당 글자 하나를 대체
grep('.......', fruit)   # 7글자 이상인 값만 검색
grep('..a', fruit)       # a의 시작 전 2글자 이상인 값만 검색

fruit


### 파일 불러오기

# 상대경로: 기준점이 존재

# 절대경로: 기준점이 필요없음


# 1. 상대경로에서 데이터 읽어오기
# - 기준점
# - 경로에 기준점의 경로는 표시되지 않음
getwd()
readLines('korea.txt')
readLines('Day03/day03.txt')  # 상대경로안의 Day03폴더 안의 day03.txt를 읽어와라
readLines('../bigdata.txt')


# 2. 절대경로
# - 전체 경로가 모두 표시되는 형태
readLines('D:/dev/weekend_bigdata/workspace/work_r/korea.txt')
readLines('D:\\dev/weekend_bigdata/workspace/work_r/Day03/day03.txt')

# 실습하기. hello.txt파일을 절대경로 방식으로 읽어와주세요.
readLines('C:/dev/hello.txt')

# - 웹에서 데이터 읽어들이기
txt1 <- readLines('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/movie_review_01.txt')


# txt1파일의 길이 체크
txt1
length(txt1)

# 실습하기. txt1의 데이터 중 영화라는 단어가 포함된 데이터를 검색해주세요.
grep('영화', txt1)

# 실습하기. grep으로 검색한 index를 이용하여 데이터 자체를 조회해주세요.
txt1[grep('영화', txt1)]


# - txt1의 데이터 중에서 40글자 이상인 데이터만 검색하기.
txt1
strrep('.', 40)
grep(strrep('.', 40), txt1)
txt1[grep(strrep('.', 40), txt1)]

# 실습하기. 다음의 조건을 만족하는 데이터를 조회해주세요.
# - 20자 이상인 것
# - 영화가 포함된 것
# - 힌트: grep에 2가지 조건을 넣으려고 하지 마세요.
#         각각을 검색한 이후에 교집합해주세요.
a <- grep(strrep('.', 20), txt1)
b <- grep('영화', txt1)
intersect(a, b)
txt1[intersect(a, b)]



# 여러 형태의 파일 읽기
# 1. pdf
# - 외부라이브러리를 이용해야함
readLines('C:/dev/movie_review_02.pdf')

install.packages('pdftools')
library('pdftools')

pdf1 <- pdf_text('C:/dev/movie_review_02.pdf')


# 읽어온 데이터의 개행문자로 데이터 나눠주기
# - 개행문자: \r\n
txt_pdf <- strsplit(pdf1, '\r\n')

# 실습하기. txt_pdf의 2번쨰 데이터만 조회해주세요.
txt_pdf
txt_pdf[[1]][2]


# 실습하기. txt_pdf의 3번방과 4번방을 합쳐서 6번방에 추가해주세요
txt_pdf[[1]][3]
txt_pdf[[1]][4]
paste0(txt_pdf[[1]][3], txt_pdf[[1]][4])
txt_pdf[[1]][6] <- paste0(txt_pdf[[1]][3], txt_pdf[[1]][4])


txt_pdf[[1]]

# txt_pdf에서 3번방과 4번방을 삭제하기
txt_pdf[[1]][c(-3, -4)]
txt_pdf[[1]] <- txt_pdf[[1]][c(-3, -4)]


txt_pdf[[1]]




# 엑셀형태를 가지는 데이터를 읽어오기
# - 엑셀형태: 테이블처럼 생겼다는 의미로 테이블은 네모 반듯한 구조입니다.

## 헤더 정보가 없는 데이터 읽어오기
mem1 <- read.table('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/member_no_title.txt')
mem1

# 메타정보(열)의 이름을 변경하기
names(mem1) <- c('이름', '성적', '평균')
mem1

# 데이터 읽어오고 해야할 작업1
# - 요약정보 확인하기
summary(mem1)


## 헤더 정보가 있는 데이터 읽어오기
mem2 <- read.table('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/member_yes_title.txt', header = T)

mem2

# 데이터 읽어오고 해야할 작업2
# -  상단(혹은 하단)의 6개 데이터만 보기
head(mem2)
tail(mem2)

# 실습하기. 평균이 평균 이상인 데이터만 조회해주세요.
# - 평균은 80.83
summary(mem2)
mem2
mem2$'평균'
mem2[, '평균']
mean(mem2[, '평균'])

mem2[mem2[, '평균'] >= mean(mem2[, '평균']), ]


# 데이터를 읽으면서 읽어들이는 행을 건너뛰기
# - skip옵션을 사용
read.table('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/member_noise.txt', header = T, skip=3)

# 읽어들이는 데이터의 양을 지정 가능
# - nrows옵션을 사용
read.table('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/member_noise.txt', header = T, skip=3, nrows=5)

# 특정한 구분자가 있는 데이터읽기
read.table('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/member_yes_sep1.txt', header = T, sep=';')

# 실습하기.
read.table('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/member_yes_sep2.txt', header = T, sep=',')

# 클립보드로부터 데이터 읽기
# - 클립보드: 콘트롤 + c 눌렀을 때 데이터 저장하고 있는 곳
read.table('clipboard', header = T, sep=';')

# 실습하기. 클립보드로 읽어들이기
readLines('clipboard')


## 결측치 처리하기
mem_na <- read.table('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/member_yes_NA.txt', header = T, sep=',')
mem_na

# 데이터 읽어들인 후 해야할 작업3
# - 결측치 확인하기
# - 결측치 해결 방법1. 특정 값으로 채우는 것
#   (데이터를 잘 알고 있을 경우에만 유용)
is.na(mem_na)
table(is.na(mem_na))
mem_na[is.na(mem_na)] <- 0
mean(mem_na$'평균')
summary(mem_na)

## 결측치 처리하기 2
mem_na2 <- read.table('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/member_yes_NA2.txt', header = T, sep=',', na.strings = '-')
mem_na2
is.na(mem_na2)

# 실습하기. 결측치를 평균 열의 평균으로 채워주세요.
mem_na2$'평균'
mem_na2[is.na(mem_na2)] <- 0
mean(mem_na2$'평균')
# 실수를 정수형태로 변경하기
as.integer(mean(mem_na2$'평균'))

mem_na2[mem_na2$'평균' == 0, '평균'] <- as.integer(mean(mem_na2$'평균'))
mem_na2



# csv파일용 함수
read.csv('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/member_yes_sep2.txt')

fruit1 <- read.csv('https://raw.githubusercontent.com/luxdolorosa/data_set/master/etc/fruits.csv', row.names = '순번')
fruit1


# 엑셀 데이터 불러오기
# - 주의사항: 네트워크에서 불러오는 형태에서는 자동으로 pw가 걸리므로
#             데이터가 안 읽어짐
install.packages('xlsx')
library('xlsx')

fruits2 <- read.xlsx('C:/dev/fruits_etc.xlsx', sheetIndex = 1, encoding = 'UTF-8')
fruits2

# 실습하기. fruits2의 구분이 결측치인 데이터의 가격 평균을 구해주세요.

is.na(fruits2)
fruits2[is.na(fruits2)]
fruits2[is.na(fruits2)] <- 3

fruits2

fruits2$'구분'==3
fruits2[fruits2$'구분'==3, '가격']
mean(fruits2[fruits2$'구분'==3, '가격'])









