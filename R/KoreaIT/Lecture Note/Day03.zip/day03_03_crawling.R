# day03_03_crawling
## 웹에 있는 데이터 긁어오기

install.packages('rvest')
library(rvest)

# 읽어올 페이지 지정
url <- 'https://en.wikipedia.org/wiki/World_Tourism_rankings'

## html파일은 <head>와 <body>로 구성되어 있습니다.
### id는 #, class는 .
tour_rank <- read_html(url)

# html페이지에서 원하는 부분 긁어오기
tables <- html_nodes(tour_rank, '.wikitable')
df <- html_table(tables[1])[[1]]
df

# 열의 정보 보기
str(df)

tail(df)

# rank, des~, inter~~ 3개의 열만 남기기
df <- df[, c(1, 2, 3)]
df

# df에서 컬럼명 변경하기
colnames(df) <- c('rank', 'des', 'tour')
df



# barplot으로 나라별 관광객 나타내기
barplot(df$rank, names.arg = df$des)


# tour칼럼의 million은 사람의 입장에서 100만이지만
# 컴퓨터에게는 문자일뿐으로 해당 부분을 없애서 
# tour칼럼을 숫자형태로 변경해야 plot을 그릴 수 있다.
df
#gsub(치환할 값, 치환될 값, 데이터)
df$tour <- gsub(' million', '', df$tour)


df
barplot(df$tour, names.arg = df$des)
str(df)
class(df$tour)

# df$tour의 데이터형을 숫자로 변경하기
df$tour <- as.numeric(df$tour)
class(df$tour)
barplot(df$tour, names.arg = df$des)
































