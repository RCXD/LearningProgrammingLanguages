#해석되지 않는 코드
'''여러줄
주석'''

#모든 프로그램은 입력 -> 처리 -> 출력
#출력함수 print()
'''
print("Hello World!")
print("정다솔")

print("엔터 출력 No",end="")#print문 끝에 출력할 문자
print("이어서 출력하기")

print("첫번째","두번째",sep=":")#각 ,마다 출력할 문자
print("%d"%10) #print(10)
'''
#입력함수 input()
'''
print("정수를 입력하세요 : ",end="")
input()
'''
####################################
num=int(input("정수를 입력하세요 : "))#input()은 통채로가 문자열값
print(num+5)






















